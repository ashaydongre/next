declare module '*.svg?url' {
  const content: any;
  export default content;
}
