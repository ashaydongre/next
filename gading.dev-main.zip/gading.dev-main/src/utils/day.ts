import day from 'dayjs';
import 'dayjs/locale/id';

export default day;
