---
title: 'Rencana bulan agustus 2019'
slug: {
  en: null,
  id: 'rencana-bulan-agustus-2019'
}
date: 2019-08-03
description: 'Apa yang harus aku lakukan pada bulan agustus ini ?'
keywords: 'kampus, planning, rencana, wisuda, polsri'
tags: ['campus', 'planning']
image: '/media/banners/2.jpg'
---

Alih - alih masuk bulan agustus.. Ga terasa ini udah bulan agustus ke 3 ketika aku pertama kali masuk kampus, 3 tahun terasa lebih cepat. Namun banyak sekali pengalaman yang aku dapat dikampus ini, Coding, love, friends, knowledge dan lainnya.

Btw, bulan kemarin aku sudah melewati sidang LA.. ya begitulah, aku mempresentasikan dan mempertanggung jawabkan apa yang aku buat, untungnya dosen pengujiku tidak melontarkan pertanyaan - pertanyaan yang menjebak, jadi alhamdulillah aku bisa menjawab semua pertanyaannya dengan baik (mungkin ?). Yang lebih beruntungnya lagi aku tidak dapet revisi memperbaiki aplikasi, jadi ya anteng aja sih wkwkw 😆. Tapi sialnya aku dapet kompensasi gara-gara keseringan telat di semester akhir ini haha, kompensasiku lumayan banyak, 11 jam lebih wkwkwk 😆, jadi mau tidak mau aku harus sering-sering dateng ke kampus untuk ngelunasin kompensasiku.

Pasca hari sidang LA, akhirnya aku bisa tidur dengan normal lagi <del>ya walaupun masih ga normal juga, masih tidur diatas jam 12 malem juga sih wkwkw</del>. Entah kenapa belakangan ini emang tidurku agak maksa, mungkin udah terbiasa ga tidur sampe pagi pas hari-hari mendekati sidang haha. Sudahlah, yang udah lewat ga perlu dibahas lebih panjang lagi, yang terpenting adalah..

***Sidang sudah lewat, apa yang harus aku lakukan selanjutnya ?***

Ya, mungkin normalnya sih memperbaiki revisi, menunggu dosen dikampus sampe sore demi dapet tanda tangan darinya, pokoknya yang berhubungan dengan ngurusin *requirement for graduation* lah. Namun apakah aku harus fokus dengan hal itu ? banyak hal lain yang bisa aku lakukan untuk meningkatkan kualitas pada diriku untuk terjun ke *real-life* yang sebenarnya nanti. Ntah kenapa, aku masih belum merasa cukup dengan kualitas diriku yang sekarang, rasanya masih banyak yang harus aku pelajari, mungkin karena aku kebanyakan liat orang-orang yang udah sukses dan bahagia dalam hidupnya dan hal itulah yang membuat aku iri. Aku yakin mereka bukan orang yang hanya mengandalkan nasib, mereka yang udah sukses dan bahagia adalah mereka yang dulunya pernah berjuang, berjuang untuk meningkatkan kualitas diri.

---

Jadi, untuk itu mungkin aku akan melakukan hal-hal ini:

- Jilid LA dengan hard-cover, burning soft-copy LA kedalam CD dan menyelesaikan semua tugas lainnya sebagai mahasiswa supaya aku bisa wisuda tahun ini.
- Bayar kompensasiku di kampus selama 11 jam
- Menyelesaikan proyek yang diberi dosen sampe tuntas.
- Dan, menunggu jadwal wisuda.. hehe
- Disamping hal-hal diatas, mungkin aku akan menyelipkan sedikit waktu untuk belajar dan meningkatkan kualitas diriku. Selain itu, ga lupa aku juga bakal membuat *quality time* bersama doi tersayang. hehe 😄
