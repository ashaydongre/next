---
title: 'Masa Depan'
slug: {
  en: null,
  id: 'masa-depan'
}
date: 2019-05-17
description: 'Kenapa belajar lebih dalam tentang teknologi ? Apa alasannya ? Well, my code is my future'
keywords: 'life, masa depan, koding, cita-cita, programming, technology, teknologi, pemrograman'
tags: ['future', 'motivation']
image: '/media/banners/3.jpg'
---

Kembali lagi dengan bacotan bullshitku di blog ini. Kali ini mungkin aku akan sedikit cerita-cerita kenapa alasan aku belajar lebih dalam tentang teknologi terkhususnya adalah ngoding. Ya walaupun tulisan ini ga penting, setidaknya aku menyimpan arsipku disini untuk aku baca nanti di masa depan. Syukur-syukur ada yang baca, syukur-syukur ada yang suka. Okey skip.. Baiklah, Untuk pertama kita masuk latar belakang dulu ya. <del>**udah kayak laporan akhir aja ni kampret, suntuk jadi aku ngingetnya.**</del>

## Background

Awalnya aku hanyalah anak SMK dengan embel-embel jurusan TKJ yang sebenernya tidak ada sedikit pun pengetahuanku tentang komputer atau teknologi melainkan hanya hobi bermain game pada saat itu. Toh, <del>SMK nya juga SMK swasta.</del> Aku juga sebenernya masuk SMK itu karena udah 2x tes SMA negeri gak masuk-masuk. Awoakwoakawok.

Namun, aku sangatlah bersyukur dengan jalan nasibku yang di beri Allah saat itu. Aku banyak belajar disana, aku dapat banyak ilmu disana, memang tidak sepenuhnya aku belajar di sekolahku, mungkin hanya dasar-dasarnya aja. Tapi, dasar-dasar itulah yang membuatku penasaran dan terus menggali lebih dalam tentang ilmu teknologi sampai pada saat aku menulis artikel ini.

Dulu akhir tahun 2013 kalo ga salah, sisi gelapku adalah install ulang, apalagi pas baru-barunya windows 8 naik daun, berbondong-bondong deh nyari crackannya. Mungkin memang karena asik sih berselancar di google sampe ketemu apa yang kita cari. Dan kalo udah dapet ? Feelnya itu loh, jadi bergengsi pake windows 8 bisa di pamerin sama temen-temenku dikelas walaupun laptopku spek kentang, tapi menariknya lagi aku bisa sirik-sirikan sama mereka supaya ikutan dan akhirnya pun aku dapet **side job**, awokawkawok. Bukan hanya temen sekelas, tapi kelas lain juga kadang dateng padaku untuk troubleshooting laptopnya. Mengapa itu bisa terjadi? Ya karena rasa penasaran tadi! Btw, 6 tahun yang lalu nyari crackan itu sulit, ga kayak sekarang, bertebaran.. tinggal ketik aja paling udah muncul di indeks pertama.

---

Aku bukanlah tipe orang yang suka pacaran saat sekolah, yang sering galau karena masalah cinta apalagi yang sering nangis karena disakiti. Aku cuma orang yang asik sendiri dengan dunia game dan job install ulangku dulu. Ya emang sih, aku keliatan cupu karena itu, tapi karena itu juga aku bisa menghasilkan uang jajanku sendiri walaupun ga seberapa, ya lumayanlah untuk remaja yang seumuranku pada saat itu. Aku pernah merasakan galau karena itu, Aku juga bertemu dengan banyak masalah karena itu, bukan masalah cinta, tapi <del>**masalah laptop orang yang crash saat aku installin driver dan software dilaptopnya.**</del> Oops ketauan deh, Aawokawkow. Tapi ujung-ujungya fix kok, hehe.

3 tahun aku sekolah disana, sungguh banyak hal yang aku pelajari, install ulang, hardware, networking, troubleshooting, tang krimping.. Hahaha. Sampe pada akhirnya pun aku bertemu dengan koding di kelas 11. Dan itupun bikin pusinggg. Aku tidak mengerti sama sekali apa yang aku ketik, aku tidak mengerti sama sekali setiap baris kode yang aku ketik, aku tidak mengerti sama sekali apa gunanya simbol-simbol gaje yang aku ketik, Aku taunya hanya mengikuti apa yang guruku ketik, *"its works ? i don't know why, its fail ? i don't fucking know why!"* Dan saat itu pula akupun agak membenci pelajaran tersebut. Aku cuma senengnya belajar troubleshooting sama install ulang doang, dan satu lagi merakit PC. Emang mungkin karena aku dulu dapet duit dari sana, dan juga hobiku bermain game jadi aku selalu mencari cara untuk meningkatkan peforma laptop dan komputerku walaupun awalnya emang dari spek yang keripik, Hahaha.

Btw, bahasa pemrograman yang pertama kali aku pelajari saat SMK dan bikin aku pusing adalah bahasa PHP. Kalo HTML mah, bukan bahasa pemrograman jadi masih enjoy-enjoy aja walaupun aku ikut pusing juga dibikinnya, Hahaha. Dulu prakteknya sih pake notepad cuy wwkwkw, setelah beberapa bulan baru gurunya nyuruh pindah ke dreamweaver. **Ngadepin error ? Seringg. Ga ngerti ? Selalu.** Hahaha.

## My way start from here!

Setelah lulus dari SMK jurusan TKJ, aku masuk POLSRI dengan prodi pilihanku yang pertama yaitu Teknik Komputer. Apa alasanku memilih prodi tersebut? Tak lebih karena latar belakangku dari sana! Aku menyangka aku akan belajar lebih dalam tentang pengetahuan yang aku pelajari saat SMK. Troubleshooting, networking, hardware, rakit PC dan sebagainya. But.. What the fuck ? Aku bertemu dengan teori-teori elektronika yang ujung-ujungnya berhubungan dengan mata pelajaran fisika sama hitung-hitungan, dan itu adalah pelajaran yang sangat aku benci daripada pelajaran pemrograman waktu SMK dulu.

Dan parahnya lagi aku ketemu mata kuliah pemrograman dikampus yang menjadi salah satu mata pelajaran yang aku benci saat SMK dulu. **Pernah merasa salah jurusan? Pernah sekali!** tapi ya, sudahlah ikutin aja, toh prodi ini juga pilihan sendiri. Kenapa harus menyesal? Bukannya itu salah dari diri kita sendiri yang milih? Lantas, haruskah kita menyalahkan Takdir? Kalo kayak kata kang pukis, "Sudah, ikutin aja.."

Jadi, aku tetap mengikuti mata kuliah dikampusku sembari aku masih hobi bermain game dan ngotak-ngatik PC serta menjalani job install ulangku kalo ada yang dateng. But.. hey, seiring waktu berlalu aku mengikuti mata kuliah pemrograman di kampus, aku jadi berpikir-pikir lagi untuk selalu membenci mata kuliah ini. Ibarat pepatah ala bisa karena biasa, sekarang aku edit dikit menjadi ala cinta karena sering bertemu, plak hahaha skiplah.

Then, lama-kelamaan aku jadi menyukai mata kuliah pemrograman karena dosen yang dikampus mengajar beserta Algoritmanya, beda dengan guru pemrogramanku yang mengajar waktu SMK cuma di tampilin kode yang sudah dibuat terus disuruh ketik tanpa menjelaskan alurnya. Ya, walaupun juga dosen dikampusku cuma mengajar dasar-dasarnya. Yang penting aku dapet pengetahuan disitu. Gara-gara sering dikasih soal pemecahan masalah aku jadi lebih rajin untuk bereksperimen di dunia koding.

---

Waktu berlalu, tahun berlalu.. Aku semakin menyukai programming. Rasa penasaranku lah yang membawaku untuk menyelam lebih dalam di lautan programming. Akhirnya aku juga mendapat teman yang seperjuangan dan sehobi dikelas. Kami pun belajar dan berjuang bersama, sampai-sampai pada akhirnya kepikiran untuk membuat TIM sendiri. Dengan tim itu kami menjadi lebih commitment dan lebih confident untuk belajar lebih dalam lagi. Kami mengikuti lomba, event dan membuat aplikasi bersama untuk membesarkan nama baik tim kami.

## My Hope

Mungkin aku tidak bisa cerita lebih banyak di blog ini, akan sangat banyak jika mau diceritakan semuanya dan lebih banyak lagi cerita yang tak harus diceritakan, Hahaha. Yang terpenting aku sangatlah bersyukur dengan Allah yang telah membawaku sejauh ini. Dan rasa penasaranlah yang membuatku menyelam sejauh ini, mungkin Dia sudah merencanakan skenario masa depanku dengan passion ini, Aamiin.

---

Jadi, kembali ke judul blog ini.. Ya, kenapa aku belajar lebih dalam di dunia teknologi? semuanya hanya karena "Masa Depan". Keinginanku adalah tak lebih dari membahagiakan orang tuaku serta bisa hidup bahagia dan nyaman, apalagi hidup bersama 'doi' yang aku cinta. Plakk, hahaha. Dan satu lagi..

> *"If you do what you love, you'll never work a day in your life."* - Marc Antony

Jadi kesimpulannya, lakukan apa yang kita cinta, dan kita tidak akan pernah merasa bekerja sehari pun dalam hidup. Makanya aku mencintai koding.. Walaupun jika nanti aku akan bekerja, aku tidak akan pernah merasa bekerja. Karena aku melakukan apa yang aku cinta.

Terlebih dari itu.. Aku ada harapan dengan timku, Semoga orang-orang yang ada di tim ini selalu solid, loyal dan komit. Ya, walaupun tim yang kami bangun ini masih mencari jati diri, tapi kami akan berusaha untuk membuat dan membesarkan tim ini sampai menjadi startup yang dilirik orang. Ya, kami harus yakin dan percaya bahwa kami bisa. **Allah tak akan mengkhianati usaha hambanya, right?**
