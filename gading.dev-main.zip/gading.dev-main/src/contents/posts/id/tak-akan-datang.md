---
title: 'Tak akan datang'
slug: {
  en: 'will-not-come',
  id: 'tak-akan-datang'
}
date: 2019-05-07
description: 'My bullshit motivation.'
keywords: 'kehidupan, waktu, motivasi'
tags: ['time', 'motivation']
image: '/media/banners/1.jpg'
---

Waktu ketika kita merasa sempurna

Waktu ketika kita merasa hebat dan mulai untuk menolong

Waktu ketika kita mulai berani untuk berbuat sesuatu

Waktu ketika kita merasa dewasa dan berhenti bermain berjam-jam

Waktu ketika kita mulai bersyukur terhadap apa yang dipunya

Waktu ketika kita merasa suci dan mulai berbuat kebaikan

Waktu ini ga akan datang~

---

Jangan tunggu motivasi untuk mulai bergerak

Jangan tunggu orang hebat untuk memulai apa yang dimau

Jangan tunggu pujian untuk mulai berpendapat

Jangan tunggu panggung untuk mulai berkarya

Jangan tunggu mati untuk mulai berbuat kebaikan

Jangan tunggu Waktu yang ga akan datang~
