---
title: 'Will not Come'
slug: {
  en: 'will-not-come',
  id: 'tak-akan-datang'
}
date: 2019-05-07
description: 'My bullshit motivation.'
keywords: 'life, time, motivation'
tags: ['time', 'motivation']
image: '/media/banners/1.jpg'
---

The time when we feel perfect

The time when we feel great and start to help

The time when we start to dare to do something

The time when we feel grown up and stop playing for hours

The time when we start to be grateful for what we have

The time when we feel holy and start doing good

This time will not come~

---

Don't wait for motivation to start moving

Don't wait for great people to start what you want

Don't wait for compliments to start arguing

Don't wait for the stage to start working

Don't wait to die to start doing good

Don't wait for the time that won't come~
