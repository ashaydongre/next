---
title: "Hai 👋, Saya Gading!"
date: 2022-06-01
description: "Insinyur Perangkat Lunak dari Palembang, Indonesia 🇮🇩"
keywords: "gading's hideout, gading homepage, gading, sutan gading, sutan gading fadhillah nasution, sutan, sutanlab, gading.dev, gading dev, persembunyian gading, website gading"
image: "/media/banners/1.jpg"
---

Saya sekarang bekerja *full-time* secara *remote* di [SIRCLO](https://sirclo.com) dalam Tim Insinyur Inti [Orami](https://orami.co.id).

Saya bersemangat untuk bereksplorasi tentang teknologi seluler dan web modern sambil mempertimbangkan tren dan teknik terbaru. Dan juga dapat menjadi pembelajar yang cepat dalam melakukan hal-hal baru dan membangun kerja tim yang baik. Kamu bisa lihat-lihat halaman [About](/about) jika ingin tahu lebih banyak tentang saya.

##### *Terima kasih sudah berkunjung.*
