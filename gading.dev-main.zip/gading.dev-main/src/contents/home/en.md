---
title: "Hi 👋, I'm Gading!"
date: 2022-06-01
description: "Software Engineer from Palembang, Indonesia 🇮🇩"
keywords: "gading's hideout, gading homepage, gading, sutan gading, sutan gading fadhillah nasution, sutan, sutanlab, gading.dev, gading dev, gading's website, gading website"
image: "/media/banners/1.jpg"
---

I'm currently working full-time remotely at [SIRCLO](https://sirclo.com) on the [Orami's](https://orami.co.id) Core Engineering team.

I'm passionate to explore about modern mobile and web technology while taking into consideration the latest trends and techniques. And also, I would be a fast learner in doing new things and building good teamwork either. You can check my [About](/about) page if you want to know more about me.

##### *Thanks for visiting me.*
