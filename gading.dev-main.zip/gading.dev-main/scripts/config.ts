/* eslint-disable @typescript-eslint/no-var-requires */
require('dotenv').config();

export * from '../src/utils/config';
